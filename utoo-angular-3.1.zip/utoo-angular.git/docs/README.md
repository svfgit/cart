Please note that documentation is not updated for the new version.
I'm working on the next release and documentation will be updated meanwhile.
Thanks for the patience.