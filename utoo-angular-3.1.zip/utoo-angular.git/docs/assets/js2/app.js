$(function () {
  $('[data-toggle="popover"]').popover();
});

$(function () {
  $('[data-toggle="tooltip"]').tooltip();
});
//# sourceMappingURL=app.js.map