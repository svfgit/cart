'use strict';

/**
 * @ngdoc function
 * @name utoo.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of utoo
 */
angular.module('utoo').controller('chipsCtrl', function DemoCtrl ($scope) {
   
   $scope.readonly = false;
    $scope.fruitNames = ['Apple', 'Banana', 'Orange'];
  });

