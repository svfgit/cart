## Utoo Material AngularJS Theme

Thanks for purchasing the Utoo Material AngularJS Theme.

Follow the documentation to install and get started with the development:

  - Link to documentation: http://utoo.strapui.com/#/dashboard/docs
  - Live Demo URL: http://utoo.strapui.com/
  - Product URL: http://www.strapui.com/themes/utoo-material-angularjs-theme/

Happy coding!
